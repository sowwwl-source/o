-- 001_init_extensions.sql
-- Core extensions
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
